import {useState, useEffect} from 'react'
import { OnChangeValue } from '../components/Body'
import { FilterData } from '../utils/helper';

const useRestorentCard =()=>{


    
    return {allRestorentData, inputValue, filteredRestorents}
}

export default useRestorentCard;