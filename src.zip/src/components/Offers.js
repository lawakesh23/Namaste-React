const Offers =()=>{
    return(
        <div>This is offers</div>
    )
}

export default Offers;