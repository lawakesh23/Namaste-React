import { sum } from "../sum"

test("Check Sum of two number",()=>{
    expect(sum(2,3)).toBe(5)
})